import { useState, type ReactNode } from "react";
import {
  Bell,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Church,
  CircleUserRound,
  Clock3,
  Guitar,
  Home,
  ListMusic,
  MapPin,
  Menu,
  Mic2,
  Music2,
  Plus,
  Search,
  Settings,
  SlidersHorizontal,
  Sparkles,
  UserPlus,
  Users,
} from "lucide-react";

import ana from "@/assets/avatar-ana.jpg";
import gabriel from "@/assets/avatar-gabriel.jpg";
import juliana from "@/assets/avatar-juliana.jpg";
import lucas from "@/assets/avatar-lucas.jpg";
import { Button } from "@/components/ui/button";

type Tab = "home" | "songs" | "setlists" | "team" | "profile";
type Overlay = "song" | "new-song" | "member" | "notifications" | "ministries" | null;

const people = [
  { name: "Gabriel Santos", role: "Vocal", image: gabriel },
  { name: "Ana Martins", role: "Violão", image: ana },
  { name: "Lucas Oliveira", role: "Bateria", image: lucas },
  { name: "Juliana Costa", role: "Teclado", image: juliana },
];

const songs = [
  { title: "Bondade de Deus", artist: "Isaías Saad", key: "G", bpm: 72 },
  { title: "Olhai Pra Ele", artist: "Morada", key: "D", bpm: 68 },
  { title: "Tu Amor Não Falha", artist: "Nívea Soares", key: "A", bpm: 74 },
  { title: "Rei da Glória", artist: "Diante do Trono", key: "E", bpm: 76 },
  { title: "Lugar Secreto", artist: "Gabriela Rocha", key: "C", bpm: 70 },
  { title: "A Casa É Sua", artist: "Casa Worship", key: "F", bpm: 71 },
];

function StatusBar() {
  return (
    <div className="status-bar" aria-hidden="true">
      <strong>9:41</strong><span>▮▮▮ ᴡɪ-ꜰɪ ▰</span>
    </div>
  );
}

function Avatar({ image, name, size = "md" }: { image: string; name: string; size?: "sm" | "md" | "lg" }) {
  return <img className={`avatar avatar-${size}`} src={image} alt={name} width={96} height={96} loading="lazy" />;
}

function Segments({ items, active = 0 }: { items: string[]; active?: number }) {
  return (
    <div className="segments">
      {items.map((item, index) => <span className={index === active ? "segment-active" : ""} key={item}>{item}</span>)}
    </div>
  );
}

function Header({ title, back, action }: { title: string; back?: () => void; action?: ReactNode }) {
  return (
    <header className="screen-header">
      {back ? <Button size="icon" variant="ghost" aria-label="Voltar" onClick={back}><ChevronLeft /></Button> : <span className="header-spacer" />}
      <h1>{title}</h1>
      <div className="header-action">{action ?? <span className="header-spacer" />}</div>
    </header>
  );
}

function BottomNav({ tab, onTab }: { tab: Tab; onTab: (tab: Tab) => void }) {
  const items: { id: Tab; label: string; icon: typeof Home }[] = [
    { id: "home", label: "Início", icon: Home },
    { id: "songs", label: "Músicas", icon: Music2 },
    { id: "setlists", label: "Setlists", icon: ListMusic },
    { id: "team", label: "Equipe", icon: Users },
    { id: "profile", label: "Perfil", icon: CircleUserRound },
  ];
  return (
    <nav className="bottom-nav" aria-label="Navegação principal">
      {items.map(({ id, label, icon: Icon }) => (
        <Button key={id} variant="ghost" className={tab === id ? "nav-active" : ""} onClick={() => onTab(id)}>
          <Icon /><span>{label}</span>
        </Button>
      ))}
    </nav>
  );
}

function HomeScreen({ open }: { open: (overlay: Overlay) => void }) {
  const shortcuts = [
    { label: "Ministérios", sub: "Veja todos os ministérios", icon: Church, action: () => open("ministries") },
    { label: "Avisos", sub: "Confira os avisos da igreja", icon: Bell, action: () => open("notifications") },
    { label: "Minhas escalas", sub: "Sua agenda de serviços", icon: CalendarDays, action: () => undefined },
    { label: "Aniversariantes", sub: "Hoje e próximos dias", icon: Users, action: () => undefined },
  ];
  return (
    <main className="screen home-screen">
      <div className="brand-row"><strong className="wordmark">AMPLY</strong><div><Button size="icon" variant="ghost" aria-label="Avisos" onClick={() => open("notifications")}><Bell /></Button><Avatar image={gabriel} name="Gabriel Santos" size="sm" /></div></div>
      <section className="welcome"><h1>Olá, Lucas!</h1><p>Que bom te ver por aqui!</p></section>
      <button className="church-row" onClick={() => open("ministries")}><span className="icon-tile"><Church /></span><span><strong>Igreja Batista Esperança</strong><small>Ministério de Louvor</small></span><ChevronRight /></button>
      <section><h2>Atalhos</h2><div className="shortcut-grid">{shortcuts.map(({ label, sub, icon: Icon, action }) => <button className="shortcut" key={label} onClick={action}><span className="icon-tile"><Icon /></span><strong>{label}</strong><small>{sub}</small></button>)}</div></section>
      <section><div className="section-title"><h2>Próximos aniversariantes</h2><button>Ver todos</button></div><div className="birthday-row">{people.map((person, index) => <div key={person.name}><Avatar image={person.image} name={person.name} /><strong>{person.name.split(" ")[0]}</strong><small>{index < 2 ? "Hoje" : "Amanhã"}</small></div>)}</div></section>
      <section className="next-event"><div><small>PRÓXIMO SETLIST</small><h2>Culto de Domingo</h2><p><CalendarDays /> 21 de set. de 2026 · 19:00</p><p><MapPin /> Templo Central</p></div><div className="event-count"><strong>12</strong><span>músicas</span></div></section>
    </main>
  );
}

function SongsScreen({ open }: { open: (overlay: Overlay) => void }) {
  return (
    <main className="screen">
      <Header title="Músicas" action={<Button size="icon" aria-label="Cadastrar música" onClick={() => open("new-song")}><Plus /></Button>} />
      <label className="search"><Search /><input aria-label="Buscar música" placeholder="Buscar música..." /><SlidersHorizontal /></label>
      <Segments items={["Todas", "Favoritas", "Recentes"]} />
      <div className="list-heading"><span>{songs.length} músicas</span><button>Ordenar por A–Z</button></div>
      <section className="song-list">{songs.map((song) => <button className="song-row" key={song.title} onClick={() => open("song")}><span className="song-art"><Music2 /></span><span className="song-copy"><strong>{song.title}</strong><small>{song.artist}</small></span><span className="song-meta"><b>{song.key}</b><small>{song.bpm} bpm</small></span><ChevronRight /></button>)}</section>
    </main>
  );
}

function SetlistsScreen() {
  return (
    <main className="screen">
      <Header title="Setlists" action={<Button size="icon" aria-label="Criar setlist"><Plus /></Button>} />
      <Segments items={["Próximos", "Passados", "Todos"]} />
      <h2 className="block-title">Em destaque</h2>
      <article className="featured-setlist"><small>DOMINGO · 19:00</small><h2>Culto de Domingo</h2><p><MapPin /> Templo Central</p><div className="stack-row"><div className="avatar-stack">{people.map(person => <Avatar key={person.name} image={person.image} name={person.name} size="sm" />)}</div><span>7 membros</span></div><div className="setlist-total"><Music2 /> 12 músicas <ChevronRight /></div></article>
      <h2 className="block-title">Próximas escalas</h2>
      <div className="simple-list">{[
        ["Ensaio Geral", "Sáb, 26 de set. · 16:00", "Ensaio"],
        ["Culto Jovem", "Sex, 25 de set. · 19:30", "Escala"],
        ["Culto Especial", "Dom, 27 de set. · 09:00", "Escala"],
      ].map(([name, date, type]) => <button key={name}><span><strong>{name}</strong><small>{date}</small><small>♫ 9 músicas</small></span><em>{type}</em><ChevronRight /></button>)}</div>
    </main>
  );
}

function TeamScreen({ open }: { open: (overlay: Overlay) => void }) {
  const team = [...people, { name: "Rafael Lima", role: "Baixo", image: gabriel }, { name: "Diego Alves", role: "Bateria", image: lucas }];
  return (
    <main className="screen">
      <Header title="Equipe" action={<Button size="sm" onClick={() => open("member")}><UserPlus /> Convidar</Button>} />
      <Segments items={["Membros", "Funções", "Instrumentos"]} />
      <label className="search"><Search /><input aria-label="Buscar membro" placeholder="Buscar membro..." /></label>
      <section className="member-list">{team.map((person, index) => <button className="member-row" key={`${person.name}-${index}`}><Avatar image={person.image} name={person.name} /><span><strong>{person.name}</strong><small>{index === 0 ? "Líder do ministério" : person.role}</small></span><em>{index === 0 ? "Administrador" : "Membro"}</em><ChevronRight /></button>)}</section>
    </main>
  );
}

function ProfileScreen({ open }: { open: (overlay: Overlay) => void }) {
  return (
    <main className="screen">
      <Header title="Perfil" action={<Button size="icon" variant="ghost" aria-label="Configurações"><Settings /></Button>} />
      <section className="profile-head"><Avatar image={gabriel} name="Gabriel Santos" size="lg" /><h1>Gabriel Santos</h1><p>gabriel@amply.com.br</p><span>Vocal · Ministério de Louvor</span></section>
      <div className="profile-stats"><div><strong>6</strong><span>músicas</span></div><div><strong>8</strong><span>escalas</span></div><div><strong>2</strong><span>ministérios</span></div></div>
      <h2 className="block-title">Minha conta</h2>
      <div className="settings-list"><button><CircleUserRound /> Dados pessoais <ChevronRight /></button><button onClick={() => open("notifications")}><Bell /> Notificações <ChevronRight /></button><button onClick={() => open("ministries")}><Church /> Meus ministérios <ChevronRight /></button><button><Settings /> Preferências <ChevronRight /></button></div>
      <Button variant="outline" className="wide-button">Sair da conta</Button>
    </main>
  );
}

function SongDetail({ back }: { back: () => void }) {
  return <main className="screen"><Header title="Detalhes da música" back={back} action={<Button size="icon" variant="ghost" aria-label="Mais opções"><Menu /></Button>} /><section className="song-hero"><div className="large-art"><Music2 /></div><h1>Bondade de Deus</h1><p>Isaías Saad</p><div><span>Tom G</span><span>72 bpm</span><span>4/4</span></div></section><div className="song-actions"><Button><Guitar /> Abrir cifra</Button><Button variant="outline"><Music2 /> Ouvir música</Button></div><section className="detail-block"><h2>Informações</h2><dl><div><dt>Tom original</dt><dd>G</dd></div><div><dt>Duração</dt><dd>4:52</dd></div><div><dt>Categoria</dt><dd>Adoração</dd></div></dl></section><section className="detail-block"><h2>Observações</h2><p>Começar suave no primeiro verso. Subir a dinâmica após a ponte e repetir o último refrão.</p></section></main>;
}

function FormScreen({ kind, back }: { kind: "song" | "member"; back: () => void }) {
  const member = kind === "member";
  return <main className="screen"><Header title={member ? "Convidar membro" : "Cadastrar música"} back={back} /><form className="form-stack" onSubmit={(event) => { event.preventDefault(); back(); }}><label>{member ? "Nome completo" : "Nome da música"}<input required placeholder={member ? "Ex.: Mariana Silva" : "Ex.: Bondade de Deus"} /></label><label>{member ? "E-mail" : "Artista"}<input required type={member ? "email" : "text"} placeholder={member ? "nome@email.com" : "Ex.: Isaías Saad"} /></label><div className="form-grid"><label>{member ? "Função" : "Tom"}<select><option>{member ? "Vocal" : "G"}</option><option>{member ? "Violão" : "A"}</option></select></label><label>{member ? "Ministério" : "BPM"}<input placeholder={member ? "Louvor" : "72"} /></label></div>{!member && <label>Observações<textarea rows={5} placeholder="Adicione orientações para a equipe..." /></label>}<Button size="lg" type="submit" className="wide-button">{member ? "Enviar convite" : "Salvar música"}</Button></form></main>;
}

function Notices({ back }: { back: () => void }) {
  return <main className="screen"><Header title="Avisos" back={back} /><Segments items={["Todos", "Importantes", "Geral"]} /><div className="notice-list"><article className="notice-important"><CalendarDays /><div><small>IMPORTANTE</small><h2>Ensaio geral – Sábado</h2><p>Nosso próximo ensaio geral será no sábado, às 16h, no templo.</p><time>12 de set. de 2026</time></div></article>{[["Nova música no repertório", "Já está disponível a cifra da música Tu Amor Não Falha."], ["Culto de jovens", "No próximo domingo teremos o culto de jovens."], ["Materiais do ministério", "O material de apoio já está disponível."]].map(([title, copy]) => <article key={title}><Bell /><div><small>GERAL</small><h2>{title}</h2><p>{copy}</p><time>10 de set. de 2026</time></div></article>)}</div></main>;
}

function Ministries({ back }: { back: () => void }) {
  const ministries = [["Louvor", "12 membros", Mic2], ["Banda", "8 membros", Guitar], ["Vocal", "6 membros", Mic2], ["Violão", "3 membros", Guitar], ["Bateria", "4 membros", Music2], ["Teclado", "3 membros", Music2], ["Outros", "1 membro", Users]] as const;
  return <main className="screen"><Header title="Ministérios" back={back} /><label className="search"><Search /><input aria-label="Buscar ministério" placeholder="Buscar ministério..." /></label><div className="ministry-list">{ministries.map(([name, count, Icon]) => <button key={name}><span className="round-icon"><Icon /></span><span><strong>{name}</strong><small>{count}</small></span><ChevronRight /></button>)}</div></main>;
}

export function AmplyApp() {
  const [tab, setTab] = useState<Tab>("home");
  const [overlay, setOverlay] = useState<Overlay>(null);
  const render = () => {
    if (overlay === "song") return <SongDetail back={() => setOverlay(null)} />;
    if (overlay === "new-song") return <FormScreen kind="song" back={() => setOverlay(null)} />;
    if (overlay === "member") return <FormScreen kind="member" back={() => setOverlay(null)} />;
    if (overlay === "notifications") return <Notices back={() => setOverlay(null)} />;
    if (overlay === "ministries") return <Ministries back={() => setOverlay(null)} />;
    if (tab === "songs") return <SongsScreen open={setOverlay} />;
    if (tab === "setlists") return <SetlistsScreen />;
    if (tab === "team") return <TeamScreen open={setOverlay} />;
    if (tab === "profile") return <ProfileScreen open={setOverlay} />;
    return <HomeScreen open={setOverlay} />;
  };
  return <div className="app-stage"><div className="phone-shell"><StatusBar />{render()}{!overlay && <BottomNav tab={tab} onTab={setTab} />}</div></div>;
}