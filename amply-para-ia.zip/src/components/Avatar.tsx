import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { useTheme } from '../contexts/ThemeContext';
import { typography } from '../constants/theme';

export function Avatar({
  uri,
  name,
  size = 40,
  mono = false,
}: {
  uri?: string | null;
  name?: string | null;
  size?: number;
  /** Fallback monocromático (Home e telas B&W) */
  mono?: boolean;
}) {
  const { colors } = useTheme();
  const letter = (name || '?').charAt(0).toUpperCase();

  if (uri) {
    return (
      <Image
        source={{ uri }}
        style={{ width: size, height: size, borderRadius: size / 2 }}
      />
    );
  }

  const bg = mono ? '#EFEFEF' : colors.primaryLight;
  const fg = mono ? '#111111' : colors.primaryDark;

  return (
    <View
      style={[
        styles.ph,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: bg,
        },
      ]}
    >
      <Text style={[styles.letter, { fontSize: size * 0.4, color: fg }]}>
        {letter}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  ph: { alignItems: 'center', justifyContent: 'center' },
  letter: { ...typography.bodyMedium, fontWeight: '700' },
});
