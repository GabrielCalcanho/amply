export type ColorTokens = {
  primary: string; primaryDark: string; primaryLight: string; primaryMuted: string;
  background: string; surface: string; surfaceSecondary: string; surfaceElevated: string;
  border: string; borderStrong: string; divider: string;
  text: string; textSecondary: string; textMuted: string; textInverse: string;
  white: string; black: string; charcoal: string;
  danger: string; dangerLight: string; success: string; successLight: string;
  warning: string; warningLight: string; info: string; infoLight: string;
  overlay: string; tabBar: string; tabBarBorder: string; headerBg: string; headerText: string; cardShadow: string;
};

export const lightColors: ColorTokens = {
  primary: '#171717', primaryDark: '#000000', primaryLight: '#EDEDED', primaryMuted: '#737373',
  background: '#F7F7F7', surface: '#FFFFFF', surfaceSecondary: '#F0F0F0', surfaceElevated: '#FFFFFF',
  border: '#E4E4E4', borderStrong: '#D1D1D1', divider: '#ECECEC',
  text: '#171717', textSecondary: '#5F5F5F', textMuted: '#8A8A8A', textInverse: '#FFFFFF',
  white: '#FFFFFF', black: '#000000', charcoal: '#2B2B2B',
  danger: '#262626', dangerLight: '#EAEAEA', success: '#262626', successLight: '#EAEAEA',
  warning: '#404040', warningLight: '#EAEAEA', info: '#404040', infoLight: '#EAEAEA',
  overlay: 'rgba(23, 23, 23, 0.45)', tabBar: '#FFFFFF', tabBarBorder: '#E4E4E4',
  headerBg: '#F7F7F7', headerText: '#171717', cardShadow: 'rgba(23, 23, 23, 0.06)',
};

export const darkColors: ColorTokens = {
  primary: '#F2F2F2', primaryDark: '#FFFFFF', primaryLight: '#303030', primaryMuted: '#A3A3A3',
  background: '#121212', surface: '#1A1A1A', surfaceSecondary: '#222222', surfaceElevated: '#282828',
  border: '#303030', borderStrong: '#444444', divider: '#2B2B2B',
  text: '#F2F2F2', textSecondary: '#A8A8A8', textMuted: '#777777', textInverse: '#121212',
  white: '#FFFFFF', black: '#000000', charcoal: '#E8E8E8',
  danger: '#F2F2F2', dangerLight: '#3A3A3A', success: '#F2F2F2', successLight: '#3A3A3A',
  warning: '#D4D4D4', warningLight: '#3A3A3A', info: '#D4D4D4', infoLight: '#3A3A3A',
  overlay: 'rgba(0, 0, 0, 0.55)', tabBar: '#1A1A1A', tabBarBorder: '#303030',
  headerBg: '#121212', headerText: '#F2F2F2', cardShadow: 'rgba(0, 0, 0, 0.35)',
};

export const colors = lightColors;
export const spacing = { xxs: 2, xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, xxxl: 40 } as const;
export const radius = { sm: 8, md: 12, lg: 16, xl: 20, full: 999 } as const;
export const shadow = {
  none: { shadowColor: 'transparent', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0, shadowRadius: 0, elevation: 0 },
  sm: { shadowColor: '#171717', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 1 },
  md: { shadowColor: '#171717', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.07, shadowRadius: 6, elevation: 2 },
  lg: { shadowColor: '#171717', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.09, shadowRadius: 12, elevation: 4 },
} as const;
export const typography = {
  h1: { fontSize: 28, fontWeight: '700' as const, letterSpacing: -0.6, lineHeight: 34 },
  h2: { fontSize: 22, fontWeight: '700' as const, letterSpacing: -0.4, lineHeight: 28 },
  h3: { fontSize: 17, fontWeight: '600' as const, letterSpacing: -0.2, lineHeight: 22 },
  body: { fontSize: 15, fontWeight: '400' as const, lineHeight: 22 },
  bodyMedium: { fontSize: 15, fontWeight: '600' as const, lineHeight: 22 },
  caption: { fontSize: 13, fontWeight: '400' as const, lineHeight: 18 },
  small: { fontSize: 11, fontWeight: '500' as const, lineHeight: 14 },
  label: { fontSize: 12, fontWeight: '600' as const, letterSpacing: 0.3, lineHeight: 16 },
} as const;
export type ThemeMode = 'light' | 'dark' | 'system';
