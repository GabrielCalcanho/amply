import { createFileRoute } from "@tanstack/react-router";
import { AmplyApp } from "@/components/AmplyApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AMPLY — Gestão para ministérios de música" },
      { name: "description", content: "Músicas, setlists, escalas e equipe em um só lugar." },
      { property: "og:title", content: "AMPLY — Gestão para ministérios de música" },
      { property: "og:description", content: "Músicas, setlists, escalas e equipe em um só lugar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <AmplyApp />;
}
