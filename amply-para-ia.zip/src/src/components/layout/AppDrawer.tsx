import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  TouchableOpacity,
  ScrollView,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { spacing, typography, radius } from '../../constants/theme';

type DrawerItem = { label: string; icon: keyof typeof Ionicons.glyphMap; route: string };

/** Opções do menu antigo — preservadas. */
const ITEMS: DrawerItem[] = [
  { label: 'Visão geral', icon: 'grid-outline', route: 'Overview' },
  { label: 'Avisos', icon: 'megaphone-outline', route: 'Announcements' },
  { label: 'Indisponibilidade', icon: 'calendar-clear-outline', route: 'Unavailability' },
  { label: 'Panorama de escala', icon: 'stats-chart-outline', route: 'ScaleOverview' },
  { label: 'Aniversariantes', icon: 'gift-outline', route: 'Birthdays' },
  { label: 'Metrônomo', icon: 'speedometer-outline', route: 'Metronome' },
  { label: 'Planos', icon: 'card-outline', route: 'Plans' },
  { label: 'Configurações', icon: 'settings-outline', route: 'Settings' },
];

const FOOTER_ITEMS: DrawerItem[] = [
  { label: 'Perfil', icon: 'person-outline', route: 'Profile' },
];

export function AppDrawer({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation<any>();
  const { church, profile } = useAuth();
  const { colors } = useTheme();

  // Escape (web)
  useEffect(() => {
    if (!visible || Platform.OS !== 'web') return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [visible, onClose]);

  const go = (route: string) => {
    onClose();
    setTimeout(() => navigation.navigate(route), 50);
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable
        style={[styles.backdrop, { backgroundColor: colors.overlay }]}
        onPress={onClose}
        accessibilityLabel="Fechar menu"
      >
        <Pressable
          style={[
            styles.panel,
            {
              paddingTop: insets.top + 16,
              paddingBottom: insets.bottom + 20,
              backgroundColor: colors.surface,
            },
          ]}
          onPress={(e) => e.stopPropagation?.()}
          accessibilityViewIsModal
          accessibilityLabel="Menu de navegação"
        >
          <View style={[styles.header, { borderBottomColor: colors.border }]}>
            <Text style={[styles.brand, { color: colors.text }]}>AMPLY</Text>
            <Text style={[styles.church, { color: colors.textSecondary }]} numberOfLines={1}>
              {church?.name ?? 'Ministério'}
            </Text>
            {profile?.name ? (
              <Text style={[styles.user, { color: colors.textMuted }]} numberOfLines={1}>
                {profile.name}
              </Text>
            ) : null}
          </View>

          <ScrollView style={styles.list} showsVerticalScrollIndicator={false}>
            {ITEMS.map((item) => (
              <TouchableOpacity
                key={item.route}
                style={styles.item}
                onPress={() => go(item.route)}
                accessibilityRole="button"
                accessibilityLabel={item.label}
              >
                <Ionicons name={item.icon} size={20} color={colors.textSecondary} />
                <Text style={[styles.itemLabel, { color: colors.text }]}>{item.label}</Text>
              </TouchableOpacity>
            ))}
            <View style={[styles.divider, { backgroundColor: colors.border }]} />
            {FOOTER_ITEMS.map((item) => (
              <TouchableOpacity
                key={item.route}
                style={styles.item}
                onPress={() => go(item.route)}
                accessibilityRole="button"
                accessibilityLabel={item.label}
              >
                <Ionicons name={item.icon} size={20} color={colors.textSecondary} />
                <Text style={[styles.itemLabel, { color: colors.text }]}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, flexDirection: 'row' },
  panel: {
    width: Platform.OS === 'web' ? 300 : '78%',
    maxWidth: 320,
    height: '100%',
    paddingHorizontal: spacing.md,
  },
  header: {
    paddingHorizontal: spacing.sm,
    paddingBottom: spacing.lg,
    borderBottomWidth: StyleSheet.hairlineWidth,
    marginBottom: spacing.sm,
  },
  brand: {
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 3,
  },
  church: { ...typography.body, marginTop: 6 },
  user: { ...typography.caption, marginTop: 2 },
  list: { flex: 1 },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: 14,
    paddingHorizontal: spacing.sm,
    borderRadius: radius.md,
    minHeight: 48,
  },
  itemLabel: { ...typography.body },
  divider: {
    height: StyleSheet.hairlineWidth,
    marginVertical: spacing.sm,
    marginHorizontal: spacing.sm,
  },
});
