import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { spacing } from '../../constants/theme';
import { MenuIcon } from './MenuIcon';

interface AppHeaderProps {
  onMenuPress: () => void;
  onBellPress?: () => void;
  onAvatarPress?: () => void;
  /** Home style: logo left, no church subtitle under logo */
  variant?: 'home' | 'default';
}

export function AppHeader({
  onMenuPress,
  onBellPress,
  onAvatarPress,
  variant = 'default',
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  const { profile } = useAuth();
  const { colors } = useTheme();
  const top = Math.max(insets.top, Platform.OS === 'web' ? 12 : 0);
  const isHome = variant === 'home';

  return (
    <View
      style={[
        styles.wrap,
        {
          paddingTop: top + 4,
          backgroundColor: colors.background,
        },
      ]}
    >
      <View style={styles.row}>
        {isHome ? (
          <Text style={[styles.brand, { color: colors.text }]} accessibilityRole="header">
            AMPLY
          </Text>
        ) : (
          <TouchableOpacity
            onPress={onMenuPress}
            style={styles.iconBtn}
            accessibilityLabel="Abrir ou fechar menu"
            accessibilityRole="button"
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <MenuIcon color={colors.text} size={22} />
          </TouchableOpacity>
        )}

        {isHome ? <View style={{ flex: 1 }} /> : (
          <View style={styles.center} pointerEvents="none">
            <Text style={[styles.brandCenter, { color: colors.text }]}>AMPLY</Text>
          </View>
        )}

        <View style={styles.right}>
          {onBellPress ? (
            <TouchableOpacity
              onPress={onBellPress}
              style={styles.iconBtn}
              accessibilityLabel="Notificações"
            >
              <Ionicons name="notifications-outline" size={22} color={colors.text} />
            </TouchableOpacity>
          ) : null}
          {onAvatarPress ? (
            <TouchableOpacity
              onPress={onAvatarPress}
              style={styles.avatarBtn}
              accessibilityLabel="Perfil"
            >
              {profile?.avatar_url ? (
                <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
              ) : (
                <View style={[styles.avatar, styles.avatarPh, { backgroundColor: colors.surfaceSecondary }]}>
                  <Text style={[styles.avatarLetter, { color: colors.text }]}>
                    {(profile?.name || '?').charAt(0).toUpperCase()}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          ) : !isHome ? (
            <View style={styles.iconBtn} />
          ) : null}
          {isHome ? null : null}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { paddingBottom: spacing.xs },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    minHeight: 48,
  },
  brand: {
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  brandCenter: {
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 2.5,
  },
  center: { flex: 1, alignItems: 'center' },
  right: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  iconBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarBtn: { marginLeft: 4 },
  avatar: { width: 32, height: 32, borderRadius: 16 },
  avatarPh: { alignItems: 'center', justifyContent: 'center' },
  avatarLetter: { fontSize: 13, fontWeight: '700' },
});
