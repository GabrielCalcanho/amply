import React from 'react';
import { View, StyleSheet } from 'react-native';

/** Hambúrguer clássico de 2 linhas (segunda menor). */
export function MenuIcon({ color, size = 22 }: { color: string; size?: number }) {
  const thick = Math.max(2, Math.round(size * 0.09));
  const gap = Math.max(5, Math.round(size * 0.28));
  const longW = size;
  const shortW = Math.round(size * 0.62);

  return (
    <View
      style={[styles.wrap, { width: size, height: size }]}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
    >
      <View
        style={{
          width: longW,
          height: thick,
          borderRadius: thick,
          backgroundColor: color,
          alignSelf: 'flex-start',
        }}
      />
      <View style={{ height: gap }} />
      <View
        style={{
          width: shortW,
          height: thick,
          borderRadius: thick,
          backgroundColor: color,
          alignSelf: 'flex-start',
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { justifyContent: 'center' },
});
