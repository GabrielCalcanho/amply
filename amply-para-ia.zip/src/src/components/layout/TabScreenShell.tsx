import React from 'react';
import { View, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { AppHeader } from './AppHeader';
import { useDrawer } from '../../contexts/DrawerContext';
import { useTheme } from '../../contexts/ThemeContext';

export function TabScreenShell({
  children,
  homeHeader = false,
}: {
  children: React.ReactNode;
  /** Header da Home: AMPLY à esquerda, sino + avatar à direita */
  homeHeader?: boolean;
}) {
  const { toggleDrawer } = useDrawer();
  const navigation = useNavigation<any>();
  const { colors } = useTheme();

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <AppHeader
        variant={homeHeader ? 'home' : 'default'}
        onMenuPress={toggleDrawer}
        onBellPress={() => navigation.navigate('Notifications')}
        onAvatarPress={() => navigation.navigate('Profile')}
      />
      <View style={styles.body}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  body: { flex: 1 },
});
