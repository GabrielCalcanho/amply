/**
 * AMPLY design tokens — monocromático (referência UI).
 * Preto, branco e cinzas. Sem cor de destaque.
 */

export const colors = {
  background: '#F5F5F5',
  surface: '#FFFFFF',
  surfaceSecondary: '#EEEEEE',
  surfaceElevated: '#FFFFFF',

  text: '#1A1A1A',
  textSecondary: '#6B6B6B',
  textMuted: '#9A9A9A',
  textInverse: '#FFFFFF',

  primary: '#1A1A1A',
  primaryDark: '#000000',
  primaryLight: '#EFEFEF',
  primaryMuted: '#8A8A8A',

  success: '#1A1A1A',
  successLight: '#EFEFEF',
  warning: '#1A1A1A',
  warningLight: '#EFEFEF',
  danger: '#1A1A1A',
  dangerLight: '#EFEFEF',
  info: '#1A1A1A',
  infoLight: '#EFEFEF',

  border: '#E8E8E8',
  borderStrong: '#D0D0D0',
  divider: '#F0F0F0',
  overlay: 'rgba(0, 0, 0, 0.4)',

  black: '#000000',
  white: '#FFFFFF',
  charcoal: '#1A1A1A',

  /** Pill inactive */
  pillBg: '#EEEEEE',
  pillText: '#6B6B6B',
};

export const spacing = {
  xxs: 4,
  xs: 8,
  sm: 12,
  md: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  full: 999,
};

export const typography = {
  h1: {
    fontSize: 28,
    fontWeight: '700' as const,
    letterSpacing: -0.5,
    lineHeight: 34,
  },
  h2: {
    fontSize: 22,
    fontWeight: '600' as const,
    letterSpacing: -0.3,
    lineHeight: 28,
  },
  h3: {
    fontSize: 17,
    fontWeight: '600' as const,
    letterSpacing: -0.2,
    lineHeight: 24,
  },
  body: {
    fontSize: 16,
    fontWeight: '400' as const,
    lineHeight: 24,
  },
  bodyMedium: {
    fontSize: 16,
    fontWeight: '500' as const,
    lineHeight: 24,
  },
  label: {
    fontSize: 14,
    fontWeight: '500' as const,
    lineHeight: 20,
  },
  caption: {
    fontSize: 13,
    fontWeight: '400' as const,
    lineHeight: 18,
  },
  small: {
    fontSize: 12,
    fontWeight: '400' as const,
    lineHeight: 16,
  },
};

export const shadow = {
  sm: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 3,
    elevation: 1,
  },
  md: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
};

export const hitSlop = { top: 8, bottom: 8, left: 8, right: 8 };
