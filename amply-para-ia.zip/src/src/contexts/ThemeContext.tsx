import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { colors as brand } from '../constants/theme';

const STORAGE_KEY = '@amply/theme-preference';

export type ThemeMode = 'light' | 'dark' | 'system';

export type ThemeColors = {
  background: string;
  surface: string;
  surfaceSecondary: string;
  surfaceElevated: string;
  text: string;
  textSecondary: string;
  textMuted: string;
  textInverse: string;
  primary: string;
  primaryDark: string;
  primaryLight: string;
  primaryMuted: string;
  success: string;
  successLight: string;
  warning: string;
  warningLight: string;
  danger: string;
  dangerLight: string;
  info: string;
  infoLight: string;
  border: string;
  borderStrong: string;
  divider: string;
  overlay: string;
  black: string;
  white: string;
  charcoal: string;
  pillBg: string;
  pillText: string;
};

const lightColors: ThemeColors = {
  background: brand.background,
  surface: brand.surface,
  surfaceSecondary: brand.surfaceSecondary,
  surfaceElevated: brand.surfaceElevated,
  text: brand.text,
  textSecondary: brand.textSecondary,
  textMuted: brand.textMuted,
  textInverse: brand.textInverse,
  primary: brand.primary,
  primaryDark: brand.primaryDark,
  primaryLight: brand.primaryLight,
  primaryMuted: brand.primaryMuted,
  success: brand.success,
  successLight: brand.successLight,
  warning: brand.warning,
  warningLight: brand.warningLight,
  danger: brand.danger,
  dangerLight: brand.dangerLight,
  info: brand.info,
  infoLight: brand.infoLight,
  border: brand.border,
  borderStrong: brand.borderStrong,
  divider: brand.divider,
  overlay: brand.overlay,
  black: brand.black,
  white: brand.white,
  charcoal: brand.charcoal,
  pillBg: brand.pillBg,
  pillText: brand.pillText,
};

const darkColors: ThemeColors = {
  background: '#000000',
  surface: '#1A1A1A',
  surfaceSecondary: '#2A2A2A',
  surfaceElevated: '#222222',
  text: '#F5F5F5',
  textSecondary: '#A0A0A0',
  textMuted: '#6B6B6B',
  textInverse: '#1A1A1A',
  primary: '#F5F5F5',
  primaryDark: '#FFFFFF',
  primaryLight: '#2A2A2A',
  primaryMuted: '#8A8A8A',
  success: '#F5F5F5',
  successLight: '#2A2A2A',
  warning: '#F5F5F5',
  warningLight: '#2A2A2A',
  danger: '#F5F5F5',
  dangerLight: '#2A2A2A',
  info: '#F5F5F5',
  infoLight: '#2A2A2A',
  border: '#2C2C2C',
  borderStrong: '#3A3A3A',
  divider: '#1F1F1F',
  overlay: 'rgba(0, 0, 0, 0.55)',
  black: '#000000',
  white: '#FFFFFF',
  charcoal: '#F5F5F5',
  pillBg: '#2A2A2A',
  pillText: '#A0A0A0',
};

type ThemeContextValue = {
  colors: ThemeColors;
  isDark: boolean;
  scheme: 'light' | 'dark';
  mode: ThemeMode;
  theme: 'light' | 'dark';
  setMode: (mode: ThemeMode) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  toggle: () => void;
};

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [mode, setModeState] = useState<ThemeMode>('system');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(STORAGE_KEY);
        if (!cancelled && stored) {
          if (stored === 'light' || stored === 'dark' || stored === 'system') {
            setModeState(stored);
          } else if (stored === 'true' || stored === 'dark-mode') {
            setModeState('dark');
          } else if (stored === 'false') {
            setModeState('light');
          }
        }
      } catch {
        /* ignore */
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const setMode = useCallback((next: ThemeMode) => {
    setModeState(next);
    AsyncStorage.setItem(STORAGE_KEY, next).catch(() => {});
  }, []);

  const setTheme = useCallback(
    (theme: 'light' | 'dark') => {
      setMode(theme);
    },
    [setMode]
  );

  const isDark = useMemo(() => {
    if (mode === 'system') return system === 'dark';
    return mode === 'dark';
  }, [mode, system]);

  const toggleTheme = useCallback(() => {
    setMode(isDark ? 'light' : 'dark');
  }, [isDark, setMode]);

  const value = useMemo<ThemeContextValue>(
    () => ({
      colors: isDark ? darkColors : lightColors,
      isDark,
      scheme: isDark ? 'dark' : 'light',
      mode,
      theme: isDark ? 'dark' : 'light',
      setMode,
      setTheme,
      toggleTheme,
      toggle: toggleTheme,
    }),
    [isDark, mode, setMode, setTheme, toggleTheme]
  );

  if (!ready) {
    return null;
  }

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return ctx;
}
