import { TabScreenShell } from '../components/layout/TabScreenShell';
import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Image,
} from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../services/supabase';
import { Profile } from '../types';
import { spacing, typography, radius, shadow } from '../constants/theme';
import { useTheme, ThemeColors } from '../contexts/ThemeContext';
import {
  todayISO,
  isBirthdayToday,
  nextBirthdayISO,
  formatDayMonth,
} from '../utils/dates';

type Bday = { id: string; name: string; avatar_url: string | null; birth_date: string; next: string };

export function HomeScreen() {
  const { colors } = useTheme();
  const styles = createStyles(colors);
  const { profile, church } = useAuth();
  const navigation = useNavigation<any>();
  const [birthdays, setBirthdays] = useState<Bday[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    if (!church) {
      setLoading(false);
      setRefreshing(false);
      return;
    }
    try {
      const { data: members } = await supabase
        .from('church_members')
        .select('user_id, profile:profiles(id, name, avatar_url, birth_date)')
        .eq('church_id', church.id);

      const list: Bday[] = [];
      for (const m of members ?? []) {
        const p = (m as any).profile as Profile | null;
        if (!p?.birth_date) continue;
        const next = nextBirthdayISO(p.birth_date);
        if (!next) continue;
        list.push({
          id: p.id,
          name: p.name,
          avatar_url: p.avatar_url,
          birth_date: p.birth_date,
          next,
        });
      }
      list.sort((a, b) => a.next.localeCompare(b.next));
      setBirthdays(list.slice(0, 8));
    } catch (e) {
      console.warn('Home load', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [church]);

  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      loadData();
    }, [loadData])
  );

  const firstName = (profile?.name || '').split(' ')[0] || 'olá';

  const shortcuts: {
    title: string;
    desc: string;
    icon: keyof typeof Ionicons.glyphMap;
    route: string;
  }[] = [
    {
      title: 'Ministérios',
      desc: 'Veja todos os ministérios',
      icon: 'business-outline',
      route: 'Ministry',
    },
    {
      title: 'Avisos',
      desc: 'Confira os avisos da igreja',
      icon: 'notifications-outline',
      route: 'Announcements',
    },
    {
      title: 'Minhas escalas',
      desc: 'Sua agenda de serviços',
      icon: 'calendar-outline',
      route: 'Setlists',
    },
    {
      title: 'Aniversariantes',
      desc: 'Hoje e próximos dias',
      icon: 'people-outline',
      route: 'Birthdays',
    },
  ];

  if (loading && !refreshing) {
    return (
      <TabScreenShell homeHeader>
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      </TabScreenShell>
    );
  }

  return (
    <TabScreenShell homeHeader>
      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              loadData();
            }}
            tintColor={colors.primary}
          />
        }
      >
        <Text style={styles.hello}>Olá, {firstName}!</Text>
        <Text style={styles.welcome}>Que bom te ver por aqui!</Text>

        {/* Church card */}
        <TouchableOpacity
          style={styles.churchCard}
          activeOpacity={0.75}
          onPress={() => navigation.navigate('Ministry')}
          accessibilityRole="button"
          accessibilityLabel={church?.name ?? 'Ministério'}
        >
          <View style={styles.churchIcon}>
            <Ionicons name="business-outline" size={20} color={colors.text} />
          </View>
          <View style={styles.churchText}>
            <Text style={styles.churchName} numberOfLines={1}>
              {church?.name ?? 'Sua igreja'}
            </Text>
            <Text style={styles.churchSub} numberOfLines={1}>
              Ministério de Louvor
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />
        </TouchableOpacity>

        {/* Atalhos 2x2 */}
        <Text style={styles.sectionTitle}>Atalhos</Text>
        <View style={styles.grid}>
          {shortcuts.map((s) => (
            <TouchableOpacity
              key={s.route}
              style={styles.shortcut}
              activeOpacity={0.75}
              onPress={() => navigation.navigate(s.route)}
              accessibilityRole="button"
              accessibilityLabel={s.title}
            >
              <View style={styles.shortcutIcon}>
                <Ionicons name={s.icon} size={20} color={colors.text} />
              </View>
              <Text style={styles.shortcutTitle}>{s.title}</Text>
              <Text style={styles.shortcutDesc} numberOfLines={2}>
                {s.desc}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Birthdays */}
        {birthdays.length > 0 ? (
          <>
            <View style={styles.sectionHead}>
              <Text style={styles.sectionTitleInline}>Próximos aniversariantes</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Birthdays')}>
                <Text style={styles.seeAll}>Ver todos</Text>
              </TouchableOpacity>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.bdayRow}
            >
              {birthdays.map((b) => {
                const today = isBirthdayToday(b.birth_date);
                const tomorrowISO = (() => {
                  const d = new Date(todayISO() + 'T12:00:00');
                  d.setDate(d.getDate() + 1);
                  const y = d.getFullYear();
                  const m = String(d.getMonth() + 1).padStart(2, '0');
                  const day = String(d.getDate()).padStart(2, '0');
                  return `${y}-${m}-${day}`;
                })();
                const isTomorrow = b.next === tomorrowISO;
                const label = today ? 'Hoje' : isTomorrow ? 'Amanhã' : formatDayMonth(b.birth_date);

                return (
                  <View key={b.id} style={styles.bdayItem}>
                    {b.avatar_url ? (
                      <Image source={{ uri: b.avatar_url }} style={styles.bdayAvatar} />
                    ) : (
                      <View style={[styles.bdayAvatar, styles.bdayPh]}>
                        <Text style={styles.bdayLetter}>
                          {(b.name || '?').charAt(0).toUpperCase()}
                        </Text>
                      </View>
                    )}
                    <Text style={styles.bdayName} numberOfLines={1}>
                      {b.name.split(' ')[0]} {b.name.split(' ')[1] || ''}
                    </Text>
                    <Text style={styles.bdayMeta}>{label}</Text>
                  </View>
                );
              })}
            </ScrollView>
          </>
        ) : null}
      </ScrollView>
    </TabScreenShell>
  );
}

function createStyles(colors: ThemeColors) {
  return StyleSheet.create({
    center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    container: {
      paddingHorizontal: spacing.lg,
      paddingTop: spacing.sm,
      paddingBottom: spacing.xxxl,
    },
    hello: {
      fontSize: 26,
      fontWeight: '700',
      color: colors.text,
      letterSpacing: -0.4,
    },
    welcome: {
      ...typography.body,
      color: colors.textSecondary,
      marginTop: 4,
      marginBottom: spacing.lg,
    },
    churchCard: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.surface,
      borderRadius: radius.xl,
      padding: spacing.md,
      marginBottom: spacing.xl,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: colors.border,
      ...shadow.sm,
      gap: spacing.sm,
    },
    churchIcon: {
      width: 44,
      height: 44,
      borderRadius: 22,
      backgroundColor: colors.surfaceSecondary,
      alignItems: 'center',
      justifyContent: 'center',
    },
    churchText: { flex: 1, minWidth: 0 },
    churchName: { ...typography.bodyMedium, color: colors.text },
    churchSub: { ...typography.caption, color: colors.textSecondary, marginTop: 2 },
    sectionTitle: {
      ...typography.h3,
      color: colors.text,
      marginBottom: spacing.sm,
    },
    sectionHead: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: spacing.lg,
      marginBottom: spacing.sm,
    },
    sectionTitleInline: { ...typography.h3, color: colors.text },
    seeAll: { ...typography.caption, color: colors.textSecondary, fontWeight: '500' },
    grid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: spacing.sm,
    },
    shortcut: {
      width: '48%',
      flexGrow: 1,
      minWidth: '46%',
      backgroundColor: colors.surface,
      borderRadius: radius.xl,
      padding: spacing.md,
      borderWidth: StyleSheet.hairlineWidth,
      borderColor: colors.border,
      ...shadow.sm,
    },
    shortcutIcon: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: colors.surfaceSecondary,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: spacing.sm,
    },
    shortcutTitle: { ...typography.bodyMedium, color: colors.text },
    shortcutDesc: { ...typography.small, color: colors.textSecondary, marginTop: 2 },
    bdayRow: { gap: spacing.md, paddingVertical: spacing.xs },
    bdayItem: { width: 76, alignItems: 'center' },
    bdayAvatar: { width: 56, height: 56, borderRadius: 28 },
    bdayPh: {
      backgroundColor: colors.surfaceSecondary,
      alignItems: 'center',
      justifyContent: 'center',
    },
    bdayLetter: { color: colors.text, fontWeight: '700', fontSize: 18 },
    bdayName: {
      ...typography.caption,
      color: colors.text,
      marginTop: 6,
      textAlign: 'center',
      width: '100%',
      fontWeight: '500',
    },
    bdayMeta: { ...typography.small, color: colors.textMuted, marginTop: 2 },
  });
}
